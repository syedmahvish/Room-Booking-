const houseDataObj = require("./house");

module.exports = { houseData: houseDataObj};
