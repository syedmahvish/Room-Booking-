const dbCollections = require("../../settings/collections");
const houseCollectionObj = dbCollections.house;
const { v1: uuidv4 } = require("uuid");
const { GridFSBucketReadStream } = require("mongodb");

/**
 * houseData : room object to store and validate room data.
 */
let houseData = {
  _id: "",
  userId: "",
  roomNumber: "",
  rent: "",
  startDate: "",
  endDate: "",
  roomType: "",
  isBooked : ""
};


/**
 * Find room into house database for given id
 * @param {} id : House id
 * Return : If room for given id is not found , error is thrown. Else return room object with complete data.
 */
async function getHouseById(id) {
  id = getValidId(id);
  let houseObj = await houseCollectionObj();

  let houseData = await houseObj.findOne({ _id: id });

  if (houseData === null) {
    throw `Error :Cannot find house with given id : ${id} into database`;
  }

  return houseData;
}

/**
 * Return all room stored in database House.
 */
async function getAllHouse() {
  const houseObj = await houseCollectionObj();
  const allHouseData = await houseObj.find().toArray();

  if (allHouseData === null) {
    throw `No house found in database`;
  }
  return allHouseData;
}

/**
 * Return all rooms stored in database House.
 */
async function getAllHouseforCurrentUser(currentUserId) {
  const houseObj = await houseCollectionObj();
  const allHouseData = await houseObj.find({ userId: currentUserId }).toArray();

  if (allHouseData === null) {
    throw `No house found in database`;
  }
  return allHouseData;
}
/**
 * Add new room into database.
 * firstly, Validate room information pass from post router.
 * If invalid info is found an array of error is thrown.
 * Secondly, Create schema with new room info.
 *
 * @param {*} houseInfo : room object that contains req.body from post router.
 * Return : New room data added in database.
 */
async function addHouse(houseInfo) {
  let data = await validateCompleteHouseInfo(houseInfo);
  if (data != null) {
    let houseSchema = createHouseSchema(data, false);
    let houseObj = await houseCollectionObj();

    let newHouse = await houseObj.insertOne(houseSchema);

    if (newHouse.insertedCount === 0) {
      throw `Error : Unable to add new house into database`;
    }

    return await this.getHouseById(newHouse.insertedId);
  }

  throw `Error : Unable to add new house into database`;
}

/**
 * Update room info into database.
 * firstly, Validate room information pass from Patch router.
 * If invalid info is found an array of error is thrown.
 * Secondly, Create schema with updated room info.
 *
 * @param {*} updateHouseInfo : room object that contains req.body from Patch router.
 * @param {*} houseId : room id that contains req.param.id from Patch router.
 * Return : Updated room data from database.
 */
async function updateHouse(houseId, updateHouseInfo) {
  houseId = getValidId(houseId);
  let data = validateCompleteHouseInfo(updateHouseInfo);

  if (data != null) {
    let houseSchema = createHouseSchema(data, true, houseId);
    let houseObj = await houseCollectionObj();
    let updateHouse = await houseObj.updateOne(
      { _id: houseId },
      { $set: houseSchema }
    );
    if (!updateHouse.modifiedCount && !updateHouse.matchedCount) {
      throw `Error : Unable to update house with id : ${houseId} into database`;
    }
    return await this.getHouseById(houseId);
  }
  throw `Error : Unable to update house with id : ${id} into database`;
}

/**
 * Delete room info from database.
 * @param {*} id : house id that contains req.param.id from Delete router.
 * Return : true if deleted successfully else error will be thrown.
 * 
 * Note: room delete functionality not handled right now, kept for future reference.
 */
async function deleteHouse(id) {
  id = getValidId(id);

  let houseObj = await houseCollectionObj();

  let removedHouse = await houseObj.removeOne({ _id: id });

  if (removedHouse.deletedCount === 0) {
    throw `Error : Unable to delete house with id : ${id} from database`;
  }

  return true;
}

/**
 * Check if room information exsist, validate and store them in houseData object.
 * Else add error in error Array.
 * @param {*} houseInfo  : room information object
 * Return : If errorArray contains error throw error.
 * Else return room data object with valid information.
 */
function validateCompleteHouseInfo(houseInfo) {
  let errorArray = [];

  if (houseInfo) {
   
    let roomIsbooked = houseInfo["isBooked"] 
    houseData.userId = houseInfo["userId"]
   
    if(houseData.userId === ""){
      roomIsbooked = false
    }

    houseData.roomNumber = houseInfo["roomNumber"];
    houseData.rent = houseInfo["rent"];
    //startDate
    if(roomIsbooked){
      if (houseInfo["startDate"]) {
        houseData.startDate = houseInfo["startDate"];
      } else {
        errorArray.push("Invalid House startDate or missing value.");
      }
  
      //endDate
      if (houseInfo["endDate"]) {
        houseData.endDate = houseInfo["endDate"];
      } else {
        errorArray.push("Invalid House endDate or missing value.");
      }
    }else{
      houseData.startDate = "";
      houseData.endDate = "";
    }

    houseData.roomType = houseInfo["roomType"];
    houseData.isBooked =  roomIsbooked;
  }

  if (errorArray.length > 0) {
    //212 3console.log(errorArray);
    throw `Errors : ${errorArray.toString()}`;
  }

  return houseData;
}

/**
 * Create schema dictionary for house data.
 * @param {} houseData  : room object with information.
 * @param {*} isUpdate : Set true if update operation is performed , else false.
 * If set false, _id will be set using uuid().
 * Return house schema dictionary.
 */
function createHouseSchema(houseData, isUpdate, houseId) {
  let houseSchema = {
    userId: houseData.userId,
    roomNumber: houseData.roomNumber,
    rent: houseData.rent,
    startDate: houseData.startDate,
    endDate: houseData.endDate,
    roomType: houseData.roomType,
    isBooked :houseData.isBooked
  };

  if (!isUpdate) {
    houseSchema._id = uuidv4();
  }

  return houseSchema;
}

/**
 * Check and validate ID .
 * @param {} id : ID to be validate
 */
function getValidId(id) {
  if (!id) {
    throw "Given  id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide  id of type object or string ";
  }

  return id;
}

module.exports = {
  getAllHouse,
  getHouseById,
  addHouse,
  updateHouse,
  deleteHouse,
  getAllHouseforCurrentUser,
};
