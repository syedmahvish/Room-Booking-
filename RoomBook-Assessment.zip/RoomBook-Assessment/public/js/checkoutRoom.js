// Get the modal
var modal = document.getElementById('id01');
var selroomNumber = document.getElementById("roomNumber")
var userId = document.getElementById("userId")

var selectedRoom;

let selectedroomData = {
    _id: "",
    roomNumber: "",
    rent: "",
    startDate: "",
    endDate: "",
    roomType: "",
    userId : "",
    isBooked : ""
  };

function denyCheckoutRoom(){
  let modal = document.getElementById("modal"+roomNumber.dataset.wpacChan);
  modal.style.display = "none";
}

function acceptCheckoutRoom(){
  selectedroomData.userId = userId.dataset.wpacChan
  let xhttpCheckoutHouse = new XMLHttpRequest();
  let method = ""
  let url = "/house";
  if (selectedRoom) {
      method = "PATCH";
      url = url + "/checkout/" + selectedRoom;
  }
    
  xhttpCheckoutHouse.open(method, url, true);
  xhttpCheckoutHouse.setRequestHeader("Content-type", "application/json");
  xhttpCheckoutHouse.setRequestHeader("X-Requested-With", "XMLHttpRequest");
  xhttpCheckoutHouse.onload = xhrSuccessHouse;
  xhttpCheckoutHouse.onerror = xhrErrorHouse;
  xhttpCheckoutHouse.send(JSON.stringify(selectedroomData));   
}


function xhrSuccessHouse() {
    msg = "Successfully checkout :" + selectedRoom;
    window.alert(msg);
    location.reload();
}

function xhrErrorHouse() {
  console.error(this.statusText);
}

function showCheckoutModal(){
  var value = event.srcElement.value;
  var array = value.split("user_id");
  
 selectedRoom =  array[0];
 selectedroomData.userId = array[1];
  if (window.confirm('Want to checkout from room with id:' + selectedRoom + " userID=" + selectedroomData.userId))
  {
    acceptCheckoutRoom();
  }
  else
  {
    denyCheckoutRoom();
  }
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}