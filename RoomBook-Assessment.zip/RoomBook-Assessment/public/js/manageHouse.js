//Select and load image
const input = document.querySelector("input");
const preview = document.querySelector(".preview");

const EL = (sel) => document.querySelector(sel);

//handling  room details
/**
 * roomData : Room object to store and validate room data.
 */
let roomData = {
  _id: "",
  roomNumber: "",
  rent: "",
  startDate: "",
  endDate: "",
  roomType: "",
  userId : "",
  isBooked : ""
};

let userData = {
  firstName: "",
  lastName: "",
  email: ""
};

//room Info validation

let roomNumber = document.getElementById("roomNumber");
let rent = document.getElementById("Rent");

let today = new Date().toISOString().split('T')[0];
let startDate = document.getElementById("startDate");
startDate.setAttribute('min', today)

let endDate = document.getElementById("endDate");
endDate.setAttribute('min', startDate.value);

let roomType = document.getElementById("roomType");

let firstName = document.getElementById("firstName");
let lastName = document.getElementById("lastName");
let email = document.getElementById("email");

let errorMessages = "";

let houseId =  document.getElementById("houseId").value; //needed to book room

window.onload = function () {
  let roomDetails = document.getElementById("Room");
  if (roomDetails) {
    
  }
};

function bookRoom() {
  errorMessages = "";

  validateCompleteInformation();

  if (errorMessages.length > 0) {
    displayError(errorMessages);
    console.log("Error in Room Information");
  } else {
    let xhttp = new XMLHttpRequest();

    let userMethod = "POST"
    let userURL = "/user";
    xhttp.open(userMethod, userURL, true);
    xhttp.responseType = 'json';
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest");
    xhttp.onload = xhrSuccess;
    xhttp.onerror = xhrError;
    xhttp.send(JSON.stringify(userData));
  }
}


function xhrSuccess() {
  var json_data = this.response; 

  roomData.userId = json_data._id;
  roomData.isBooked = true

  let xhttpHouse = new XMLHttpRequest();
  let method = "POST";
  let url = "/house";
    
  if (houseId) {
      method = "PATCH";
      url = url + "/" + houseId;
  }
    
  xhttpHouse.open(method, url, true);
  xhttpHouse.setRequestHeader("Content-type", "application/json");
  xhttpHouse.setRequestHeader("X-Requested-With", "XMLHttpRequest");
  xhttpHouse.send(JSON.stringify(roomData));
    
  if (xhttpHouse.responseText) {
      console.log("xhttp.responseText=" + xhttpHouse.responseText);
  }
  if (houseId) {
    msg = "Room number :" +  roomNumber.value + " is booked successfully.";
    window.alert(msg);
    location.reload();
    window.location.replace("http://localhost:3000/house");
  }
}

function xhrError() {
  console.error(this.statusText);
}

function validateCompleteInformation() {
  roomData.roomType = roomType.value
  roomData.roomNumber = roomNumber.value
  roomData.rent = rent.value

  if(isValidString(firstName)){
    userData.firstName = firstName.value;
  }else{
    errorMessages += "\nEnter valid first name"
  }
  if(isValidString(lastName)){
    userData.lastName = lastName.value;
  }else{
    errorMessages += "\nEnter valid last name"
  }
 
  if(isValidEmail(email.value)){
    userData.email = email.value;
  }else{
    errorMessages += "\nEnter valid email address"
  }

  if(isValidDate(startDate)){
    roomData.startDate = startDate.value
  }else{
    errorMessages += "\nEnter valid checkin date"
  }

  if(isValidDate(endDate) && endDate.value > startDate.value){
    roomData.endDate = endDate.value
  }else{
    errorMessages += "\nEnter valid checkout date"
  }

}


function isValidEmail(email) {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}


function displayError() { 
    window.alert("\nPlease correct following errors : \n"  + errorMessages)
}

function isValidDate(inputText) {
  var pdate = inputText.value.split("-");
  var yy = parseInt(pdate[0]);
  var mm = parseInt(pdate[1]);
  var dd = parseInt(pdate[2]);

  let date = mm + "/" + dd + "/" + yy;
  var dateformat = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/; ///^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
  // Match the date format through regular expression
  if (date.match(dateformat)) {
    // Create list of days of a month [assume there is no leap year by default]
    var ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (mm == 1 || mm > 2) {
      if (dd > ListofDays[mm - 1]) {
        return false;
      }
    }

    if (mm == 2) {
      var lyear = false;
      if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
        lyear = true;
      }
      if (lyear == false && dd >= 29) {
        return;
      }
      if (lyear == true && dd > 29) {
        return;
      }
    }
  } else {
    return;
  }

  return date;
}


function isValidString(input) {
  if (
    input &&
    input.value &&
    typeof input.value === "string" &&
    input.value.trim().length > 0
  ) {
    return true;
  }
  return false;
}
