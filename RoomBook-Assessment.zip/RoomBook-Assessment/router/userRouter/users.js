const express = require("express");
const router = express.Router();
const data = require("../../data/userData");
const userData = data.users;

// get all users who booked room
router.get("/", async (req, res) => {
  try {
    const userList = await userData.getAllUsers();
    res.json(userList);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});

// get user by ids
router.get("/:id", async (req, res) => {
  try {
    let user = await userData.getUserById(req.params.id);
    res.json(user);
  } catch (e) {
    res.status(404).json({ error: "User not found" });
  }
});

// add guest into user database who booked a room
router.post("/", async (req, res) => {
  let userInfo = req.body;

  if (!userInfo) {
    res.status(400).json({ error: "You must provide data to create a user" });
    return;
  }
  if (Object.keys(userInfo).length === 0) {
    res.status(400).json({ error: "You must provide data without null body" });
    return;
  }
  if (!userInfo.firstName) {
    res.status(400).json({ error: "You must provide a firstName" });
    return;
  }
  if (!userInfo.lastName) {
    res.status(400).json({ error: "You must provide a lastName" });
    return;
  }
  
  if (!userInfo.email) {
    res.status(400).json({ error: "You must provide a email" });
    return;
  }
  
  try {
    const newUser = await userData.addUser(
      userInfo.firstName,
      userInfo.lastName,
      userInfo.email,
    );
    res.json(newUser);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});

//delete guest from user database once they checkout
router.delete("/:id", async (req, res) => {
  if (!req.params.id) {
    res.status(400).json({ error: "You must Supply and ID to delete" });
    return;
  }
  try {
    await userData.getUserById(req.params.id);
  } catch (e) {
    res.status(404).json({ error: "user not found" });
    return;
  }
  try {
    await userData.removeUser(req.params.id);
    res.sendStatus(200);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});

module.exports = router;
