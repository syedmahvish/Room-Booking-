const express = require("express");
const router = express.Router();
const house = require("../../data/houseData");
const houseData = house.houseData;
const user = require("../../data/userData");
const userData = user.users;


//Get list of all rooms
router.get("/", async (req, res) => {
  try {
    let houseList = await houseData.getAllHouse();

    res.render("pages/houseList", {
      title: "Main Page",
      list : houseList
    });
  } catch (error) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",
     
    });
  }
});

//Book a room with given id
router.get("/bookRoom/:id", async (req, res) => {
  console.log("most outside Edit house");
  try {
   
    let houseId = "";
    if (req.params.id) {
      houseId = req.params.id;
    }

    let house = await houseData.getHouseById(houseId);

    console.log("Edit house=" + JSON.stringify(house));
    
    res.render("pages/houseManage", {
      title: "Book room no: " + house.roomNumber,
      houseDetail: house,
      houseId : houseId
    });
  } catch (error) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",
      
    });
  }
});


//Checkout from Room of given id
router.patch("/checkout/:id", async (req, res) => {
  if (!req.params.id || !req.body || Object.keys(req.body).length === 0) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",    
    });
    return;
  }

  let newHouse = req.body
  let oldHouse = null

  try {
    await userData.removeUser(newHouse.userId)
  } catch (error) {
    res.status(404).render("pages/erroraccess", {
      title: "Error : Cannot delete user",   
    });
  }
  
  
  newHouse.userId = ""
  newHouse.isBooked = false;
  newHouse.startDate = "";
  newHouse.endDate = "";
  try {
    oldHouse = await houseData.getHouseById(req.params.id);
    newHouse.rent = oldHouse.rent
    newHouse.roomType = oldHouse.roomType
    newHouse.roomNumber = oldHouse.roomNumber
  } catch (error) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",
      
    });
  }

  try {
    let updateHouse = await houseData.updateHouse(req.params.id, newHouse);
    res.json(updateHouse);
  } catch (error) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",
      
    });
  }
});

//Update room information for booking
router.patch("/:id", async (req, res) => {
  if (!req.params.id || !req.body || Object.keys(req.body).length === 0) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",
      
    });
    return;
  }

  let newHouse = req.body;
  let oldHouse = "";
  try {
    oldHouse = await houseData.getHouseById(req.params.id);
    oldHouse = checkAndUpdate(newHouse, oldHouse);
  } catch (error) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",    
    });
  }

  try {
    let updateHouse = await houseData.updateHouse(req.params.id, oldHouse);
    res.json(updateHouse);
  } catch (error) {
    res.status(404).render("pages/erroraccess", {
      title: "Error Page",
     
    });
  }
});

function checkAndUpdate(newHouse, oldHouse) {
 
  if (newHouse.userId && newHouse.userId != oldHouse.userId) {
    oldHouse.userId = newHouse.userId;
  }

  if (newHouse.roomNumber && newHouse.roomNumber != oldHouse.roomNumber) {
    oldHouse.roomNumber = newHouse.roomNumber;
  }
  
  if (newHouse.rent && newHouse.rent != oldHouse.rent) {
    oldHouse.rent = newHouse.rent;
  }

  if (newHouse.startDate && newHouse.startDate != oldHouse.startDate) {
    oldHouse.startDate = newHouse.startDate;
  }

  if (newHouse.endDate && newHouse.endDate != oldHouse.endDate) {
    oldHouse.endDate = newHouse.endDate;
  }
  

  if (newHouse.roomType && oldHouse.roomType != newHouse.roomType) {
    oldHouse.roomType = newHouse.roomType;
  }

  if (newHouse.isBooked && oldHouse.isBooked != newHouse.isBooked) {
    oldHouse.isBooked = newHouse.isBooked;
  }

  return oldHouse;
}

  
module.exports = router;
