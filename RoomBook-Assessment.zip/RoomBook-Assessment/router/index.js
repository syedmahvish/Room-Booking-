/*
 * @Descripttion: 
 * @version: 
 * @Author: sueRimn
 * @Date: 2020-08-11 19:54:39
 * @LastEditors: Yiqun Peng
 * @LastEditTime: 2020-08-18 13:10:53
 */
// const houseconstructorMethod = require("./userRouter/index");
// const userconstructorMethod = require("./houseRouter/index");

// const constructorMethod = (app) => {
//   houseconstructorMethod.houseconstructorMethod;
//   userconstructorMethod.userconstructorMethod;
// };

// module.exports = constructorMethod;
const userRoutes = require("./userRouter/users");
const parser = require("body-parser");
const houseRoutes = require("./houseRouter/house");

const constructorMethod = (app) => {
  //for user
  app.use(parser.json());
  app.use("/user", userRoutes);

  //house
  app.use("/house", houseRoutes);

  app.use("*", (req, res) => {
      res.render("pages/erroraccess", {
        title: "Access Error",
      });
});
}

module.exports = constructorMethod;
