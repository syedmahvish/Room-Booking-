/*
 * @Descripttion: 
 * @version: 
 * @Date: 2020-08-19 17:06:14
 * @LastEditors: Yiqun Peng
 * @LastEditTime: 2020-08-19 19:12:49
 */

const dbConnection = require("../settings/connections")
const house = require("../data/houseData")
const houseData = house.houseData;

const room1 = {
  "userId": "",
  "roomNumber": "01",
  "rent": "200",
  "startDate": null,
  "endDate": null,
  "roomType" : "single",
  "isBooked" : false
};

const room2 = {
  "userId": "",
  "roomNumber": "02",
  "rent": "300",
  "startDate": "",
  "endDate": "",
  "roomType" : "double",
  "isBooked" : false
};

const room3 = {
  "userId": "",
  "roomNumber": "03",
  "rent": "400",
  "startDate": "",
  "endDate": "",
  "roomType" : "single",
  "isBooked" : false
};

const room4 = {
  "userId": "",
  "roomNumber": "04",
  "rent": "200",
  "startDate": "",
  "endDate": "",
  "roomType" : "single",
  "isBooked" : false
};

const room5 = {
  "userId": "",
  "roomNumber": "05",
  "rent": "900",
  "startDate": "",
  "endDate": "",
  "roomType" : "single",
  "isBooked" : false
};
const room6 = {
  "userId": "",
  "roomNumber": "06",
  "rent": "600",
  "startDate": "",
  "endDate": "",
  "roomType" : "double",
  "isBooked" : false
};

const room7 = {
    "userId": "",
    "roomNumber": "07",
    "rent": "1000",
    "startDate": "",
    "endDate": "",
    "roomType" : "double",
    "isBooked" : true
  };



const main = async () => {
    let db = {};
    try{
        db = await dbConnection();
        await db.dropDatabase();   
    }catch(e){
        console.log(e);
    }
   
    let createroom1 = {}
    try{
        createroom1 = await houseData.addHouse(room1);
    }catch(e){
        console.log(e);
    }
    let createhouse2 = {}
    try{
        createhouse2 = await houseData.addHouse(room2);
    }catch(e){
        console.log(e);
    }
    let createhouse3 = {}
    try{
        createhouse3 = await houseData.addHouse(room3);
    }catch(e){
        console.log(e);
    }
    let createhouse4 = {}
    try{
        createhouse4 = await houseData.addHouse(room4);
    }catch(e){
        console.log(e);
    }
    let createhouse5 = {}
    try{
        createhouse5 = await houseData.addHouse(room5);
    }catch(e){
        console.log(e);
    }
    let createhouse6 = {}
    try{
        createhouse6 = await houseData.addHouse(room6);
    }catch(e){
        console.log(e);
    }

    let createhouse7 = {}
    try{
        createhouse7 = await houseData.addHouse(room7);
    }catch(e){
        console.log(e);
    }
    
};

main().catch(console.log);
